simple_clause!(NoHavingClause, HavingClause, " HAVING ");

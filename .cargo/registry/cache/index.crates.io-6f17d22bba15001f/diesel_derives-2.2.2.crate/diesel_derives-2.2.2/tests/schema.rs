table! {
    users {
        id -> Integer,
        name -> Text,
        hair_color -> Nullable<Text>,
        r#type -> Nullable<Text>,
    }
}

table! {
    users_ {
        id -> Integer,
        name -> Text,
        hair_color -> Nullable<Text>,
        r#type -> Nullable<Text>,
    }
}
